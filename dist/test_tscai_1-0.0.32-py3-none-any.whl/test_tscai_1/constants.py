number_of_epochs = {
                    'mlp': 5000,
                    'cnn': 2000,
                    'fcn': 2000,
                    'resnet': 1500,
                    'inception': 1500
                    }

number_of_batches = {
                    'cnn': 16,
                    'inception': 64,
                    }


